#!/bin/bash
gcc -o chmod chmod.c
gcc -o help help.c
gcc -o mkdir mkdir.c
gcc -o mkfile mkfile.c
gcc -o rmdir rmdir.c
gcc -o shdir shdir.c
gcc -o shfile shfile.c
