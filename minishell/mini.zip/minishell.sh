#!/bin/bash
gcc -o minishell minishell.c
./minishell
